﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YuldashevPr5Mobail.Models
{
    public class Dish
    {
        public int DishId { get; set; }

        public int DishTypeId { get; set; }

        public string NameDish { get; set; }

        public string CookingTime { get; set;}
    }
}
