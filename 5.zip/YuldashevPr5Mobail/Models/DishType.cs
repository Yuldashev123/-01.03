﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YuldashevPr5Mobail.Models
{
    public class DishType
    {
        public int DishTypeId { get; set; }

        public string NameType { get; set; }
    }
}
