﻿  using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using YuldashevPr5Mobail.Contexts;
using YuldashevPr5Mobail.Models;

namespace YuldashevPr5Mobail.ViewModels
{
    public class ClientsViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Client> _Clients;

        public ObservableCollection<Client> Clients
        {
            get
            {
                return _Clients;
            }

            set
            {
                _Clients = value;
                OnPropertyChanged();
            }
        }


        private Client _NewClient;

        public Client NewClient
        {
            get
            {
                return _NewClient;
            }

            set
            {
                _NewClient = value;
                OnPropertyChanged();
            }
        }

        private void GetClients()
        {
            using (var context = new Context())
            {
                Clients = new ObservableCollection<Client>(context.Clients.ToList());
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #region Добавление
        public DelegateCommand ProcessClientCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ProcessClient();
                });
            }
        }

        private void AddClient()
        {
            using (var context = new Context())
            {
                context.Clients.Add(NewClient);
                context.SaveChanges();
            }
            Clients.Add(NewClient);
            ClearClient();
        }
        #endregion
        private void UpdateClient()
        {
            using (var context = new Context())
            {
                context.Clients.Update(NewClient);
                context.SaveChanges();
            }
            GetClients();
            ClearClient();
        }

        private void ProcessClient()
        {
            if(NewClient.ClientId==0)
            {
                AddClient();
            }

            else
            {
                UpdateClient();
            }
        }

        public DelegateCommand ClearClientfCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ClearClient();
                });
            }
        }

        private void ClearClient()
        {
            NewClient = new Client();
        }

        public DelegateCommand DeleteClientCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    DeleteClient((int)o);
                });
            }
        }

        private void DeleteClient(int id)
        {
            using (var context = new Context())
            {
                Client clientForDelete = context.Clients.Find(id);
                context.Clients.Remove(clientForDelete);
                context.SaveChanges();
            }
            GetClients();
        }

        public ClientsViewModel()
        {
            GetClients();
            NewClient = new Client();
        }




    }
}
