﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using YuldashevPr5Mobail.Contexts;
using YuldashevPr5Mobail.Models;

namespace YuldashevPr5Mobail.ViewModels
{
    public class DishsViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Dish> _Dishs;

        public ObservableCollection<Dish> Dishs
        {
            get
            {
                return _Dishs;
            }
                   
            set
            {
                _Dishs = value;
                OnPropertyChanged();
            }
        }


        private Dish _NewDish;

        public Dish NewDish
        {
            get
            {
                return _NewDish;
            }

            set
            {
                _NewDish = value;
                OnPropertyChanged();
            }
        }

        private void GetDishs()
        {
            using (var context = new Context())
            {
                Dishs = new ObservableCollection<Dish>(context.Dishs.ToList());
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #region Добавление
        public DelegateCommand ProcessDishCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ProcessDish();
                });
            }
        }
        private void AddDish()
        {
            using (var context = new Context())
            {
                context.Dishs.Add(NewDish);
                context.SaveChanges();
            }
            Dishs.Add(NewDish);
            ClearDish();
        }
        private void UpdateDish()
        {
            using (var context = new Context())
            {
                context.Dishs.Update(NewDish);
                context.SaveChanges();
            }
            GetDishs();
            ClearDish();
        }
        private void ProcessDish()
        {
            if (NewDish.DishId == 0)
            {
                AddDish();
            }
            else
            {
                UpdateDish();
            }
        }
        #endregion

        public DelegateCommand ClearDishCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ClearDish();
                });
            }
        }
        private void ClearDish()
        {
            NewDish = new Dish();
        }

        public DelegateCommand DeleteDishCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    DeleteDish((int)o);
                });
            }
        }

        private void DeleteDish(int id)
        {
            using (var context = new Context())
            {
                Dish chefForDelete = context.Dishs.Find(id);
                context.Dishs.Remove(chefForDelete);
                context.SaveChanges();
            }
            GetDishs();
        }

        public DishsViewModel()
        {
            GetDishs();
            NewDish = new Dish();
        }
    }
}
