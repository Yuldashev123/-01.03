﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using YuldashevPr5Mobail.Contexts;
using YuldashevPr5Mobail.Models;

namespace YuldashevPr5Mobail.ViewModels
{
    public class DishTypesViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<DishType> _DishTypes;

        public ObservableCollection<DishType> DishTypes
        {
            get
            {
                return _DishTypes;
            }

            set
            {
                _DishTypes = value;
                OnPropertyChanged();
            }
        }


        private DishType _NewDishType;

        public DishType NewDishType
        {
            get
            {
                return _NewDishType;
            }

            set
            {
                _NewDishType = value;
                OnPropertyChanged();
            }
        }

        private void GetDishTypes()
        {
            using (var context = new Context())
            {
                DishTypes = new ObservableCollection<DishType>(context.DishTypes.ToList());
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #region Добавление
        public DelegateCommand AddDishTypeCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    AddDishType();
                });
            }
        }

        private void AddDishType()
        {
            using (var context = new Context())
            {
                context.DishTypes.Add(NewDishType);
                context.SaveChanges();
            }
            DishTypes.Add(NewDishType);
            NewDishType = new DishType();
        }
        #endregion

        public DelegateCommand ProcessDishTypeCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ProcessDishType();
                });
            }
        }

        private void UpdateDishType()
        {
            using (var context = new Context())
            {
                context.DishTypes.Update(NewDishType);
                context.SaveChanges();
            }
            GetDishTypes();
            ClearDishType();
        }
        private void ProcessDishType()
        {
            if (NewDishType.DishTypeId == 0)
            {
                AddDishType();
            }
            else
            {
                UpdateDishType();
            }
        }


        public DelegateCommand ClearDishTypeCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ClearDishType();
                });
            }
        }
        private void ClearDishType()
        {
            NewDishType = new DishType();
        }

        public DelegateCommand DeleteDishTypeCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    DeleteDishType((int)o);
                });
            }
        }

        private void DeleteDishType(int id)
        {
            using (var context = new Context())
            {
                DishType dishTypeForDelete = context.DishTypes.Find(id);
                context.DishTypes.Remove(dishTypeForDelete);
                context.SaveChanges();
            }
            GetDishTypes();
        }

        public DishTypesViewModel()
        {
            GetDishTypes();
            NewDishType = new DishType();
        }
    }
}
