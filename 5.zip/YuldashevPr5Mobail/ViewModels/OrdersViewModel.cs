﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using YuldashevPr5Mobail.Contexts;
using YuldashevPr5Mobail.Models;

namespace YuldashevPr5Mobail.ViewModels
{
    public class OrdersViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Order> _Orders;

        public ObservableCollection<Order> Orders
        {
            get
            {
                return _Orders;
            }

            set
            {
                _Orders = value;
                OnPropertyChanged();
            }
        }


        private Order _NewOrder;

        public Order NewOrder
        {
            get
            {
                return _NewOrder;
            }

            set
            {
                _NewOrder = value;
                OnPropertyChanged();
            }
        }

        private void GetOrders()
        {
            using (var context = new Context())
            {
                Orders = new ObservableCollection<Order>(context.Orders.ToList());
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #region Добавление
        public DelegateCommand AddOrderCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    AddOrder();
                });
            }
        }

        private void AddOrder()
        {
            using (var context = new Context())
            {
                context.Orders.Add(NewOrder);
                 context.SaveChanges();
            }
            Orders.Add(NewOrder);
            NewOrder = new Order();
        }
        #endregion
        public DelegateCommand ProcessOrderCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ProcessOrder();
                });
            }
        }

        private void UpdateOrder()
        {
            using (var context = new Context())
            {
                context.Orders.Update(NewOrder);
                context.SaveChanges();
            }
            GetOrders();
            ClearOrder();
        }
        private void ProcessOrder()
        {
            if (NewOrder.OrderId == 0)
            {
                AddOrder();
            }
            else
            {
                UpdateOrder();
            }
        }


        public DelegateCommand ClearOrderCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ClearOrder();
                });
            }
        }
        private void ClearOrder()
        {
            NewOrder = new Order();
        }

        public DelegateCommand DeleteOrderCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    DeleteOrder((int)o);
                });
            }
        }

        private void DeleteOrder(int id)
        {
            using (var context = new Context())
            {
                Order orderForDelete = context.Orders.Find(id);
                context.Orders.Remove(orderForDelete);
                context.SaveChanges();
            }
            GetOrders();
        }

        public OrdersViewModel()
        {
            GetOrders();
            NewOrder = new Order();
        }
    }
}
