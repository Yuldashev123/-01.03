﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using YuldashevPr5Mobail.Contexts;
using YuldashevPr5Mobail.Models;

namespace YuldashevPr5Mobail.ViewModels
{
    public class ChefsViewModel : INotifyPropertyChanged
    {
        private ObservableCollection<Chef> _Chefs;

        public ObservableCollection<Chef> Chefs
        {
            get
            {
                return _Chefs;
            }

            set
            {
                _Chefs = value;
                OnPropertyChanged();
            }
        }


        private Chef _NewChef;

        public Chef NewChef
        {
            get
            {
                return _NewChef;
            }

            set
            {
                _NewChef = value;
                OnPropertyChanged();
            }
        }

        private void GetChefs()
        {
            using (var context = new Context())
            {
                Chefs = new ObservableCollection<Chef>(context.Chefs.ToList());
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #region Добавление/Изменение
        public DelegateCommand ProcessChefCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ProcessChef();
                });
            }
        }
        private void AddChef()
        {
            using (var context = new Context())
            {
                context.Chefs.Add(NewChef);
                context.SaveChanges();
            }
            Chefs.Add(NewChef);
            ClearChef();
        }
        private void UpdateChef()
        {
            using (var context = new Context())
            {
                context.Chefs.Update(NewChef);
                context.SaveChanges();
            }
            GetChefs();
            ClearChef();
        }
        private void ProcessChef()
        {
            if( NewChef.ChefId == 0)
            {
                AddChef();
            }
            else
            {
                UpdateChef();
            }
        }
        #endregion

        public DelegateCommand ClearChefCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ClearChef();
                });
            }
        }
        private void ClearChef()
        {
            NewChef = new Chef();
        }

        public DelegateCommand DeleteChefCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    DeleteChef((int)o);
                });
            }
        }

        private void DeleteChef(int id)
        {
            using (var context = new Context())
            {
                Chef chefForDelete = context.Chefs.Find(id);
                context.Chefs.Remove(chefForDelete);
                context.SaveChanges();
            }
            GetChefs();
        }

        public ChefsViewModel()
        {
            GetChefs();
            NewChef = new Chef();
        }
    }
}

