﻿using Microsoft.EntityFrameworkCore;
using YuldashevPr5Mobail.Models;
namespace YuldashevPr5Mobail.Contexts
{
    public class Context : DbContext
    {
        public DbSet<Chef> Chefs { get; set; }
        public DbSet<Client> Clients { get; set; }
        public DbSet<Dish> Dishs { get; set; }
        public DbSet<DishType> DishTypes { get; set; }
        public DbSet<Order> Orders { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=DESKTOP-LDJ4019\\SQLEXPRESS;Database=Kitchen;Trusted_Connection=True;TrustServerCertificate=True");
        }
    }
}
