﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Yuldashev.Models;

namespace Yuldashev.Contexts
{
    public class Context: DbContext
    {
        public DbSet<Director> directors { get; set; }
        public DbSet<Movie> movies { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=DESKTOP-PK64UE3\\SQLEXPRESS;Database=Yuldashev;Trusted_Connection=True;TrustServerCertificate=True") ;
        }
    }
    
}
