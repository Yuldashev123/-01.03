﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yuldashev.Models
{
    public class Director
    {
        public int directorid {  get; set; }

        public string fullname { get; set; }

        public int NamberOfFilms { get; set; }

        public int age { get; set; }
    }
}
