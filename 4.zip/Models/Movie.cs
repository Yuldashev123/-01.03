﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yuldashev.Models
{
    public class Movie
    {
        public int movieid { get; set; }

        public int directorid { get; set; }

        public string title { get; set; }

        public DateTime release {  get; set; }

        public string country { get; set; }
    }
}
