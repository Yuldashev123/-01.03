﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Yuldashev.Contexts;
using Yuldashev.Models;

namespace Yuldashev.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        public void OnPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


        private IEnumerable<Director> _directors;

        public IEnumerable<Director> directors
        {
            get
            {
                return _directors;
            }

            set
            {
                _directors = value;
                OnPropertyChanged();
            }
        }


        private IEnumerable<Movie> _movies;

        public IEnumerable<Movie> movies
        {
            get
            {
                return _movies;
            }

            set
            {
                _movies = value;
                OnPropertyChanged();
            }
        }

        private void GetDirector()
        {
            using (var context = new Context())
            {
                directors = context.directors.ToList();
            }
        }

        private void GetMovie()
        {
            using (var context = new Context())
            {
                movies = context.movies.ToList();
            }
        }

        private Movie _newmovies;

        public Movie newmovies
        {
            get
            {
                return _newmovies;
            }

            set
            {
                _newmovies = value;
                OnPropertyChanged();
            }
        }

        public DelegateCommand Addnewmovie
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    AddNewMovie();
                });
                
            }
        }

        private void AddNewMovie()
        {
            using (var context = new Context())
            {
                context.movies.Add(newmovies);
                context.SaveChanges();
                movies = context.movies.ToList();
            }
            newmovies = new Movie();
        }

        public DelegateCommand Deletemovie
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    DeleteMovie((int)o);
                });

            }
        }

        private void DeleteMovie(int movieId)
        {
            using(var context = new Context())
            {
                Movie movieDelete = context.movies.Find(movieId);
                context.movies.Remove(movieDelete);
                context.SaveChanges();
                movies = context.movies.ToList();
            }
        }

        public MainViewModel()
        {
            newmovies = new Movie();
            GetDirector();
            GetMovie();
        }




    }
}
